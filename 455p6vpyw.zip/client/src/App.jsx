import React, { useEffect, useState } from "react";
import "./App.css";

function App() {
  const [activePage, setActivePage] = useState("home");

  const [events, setEvents] = useState([]);
  const [participants, setParticipants] = useState([]);

  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");

  const [eventForm, setEventForm] = useState({
    title: "",
    description: "",
    date: "",
    venue: "",
    maxParticipants: ""
  });

  const [registrationForm, setRegistrationForm] = useState({
    eventId: "",
    name: "",
    email: "",
    phone: ""
  });

  const [teamForm, setTeamForm] = useState({
    eventId: "",
    teamName: "",
    leaderName: "",
    members: [
      {
        name: "",
        email: ""
      }
    ]
  });

  // ==============================
  // LOAD EVENTS
  // ==============================

  const loadEvents = async () => {
    try {
      const response = await fetch("/api/events");

      if (!response.ok) {
        throw new Error("Failed to load events");
      }

      const data = await response.json();
      setEvents(data);
    } catch (error) {
      console.error(error);
      alert("Unable to load events");
    }
  };

  useEffect(() => {
    loadEvents();
  }, []);

  // ==============================
  // LOAD PARTICIPANTS
  // ==============================

  const loadParticipants = async () => {
    try {
      const response = await fetch("/api/registrations");

      if (!response.ok) {
        throw new Error("Failed to load participants");
      }

      const data = await response.json();
      setParticipants(data);
    } catch (error) {
      console.error(error);
      alert("Unable to load participants");
    }
  };

  // ==============================
  // NAVIGATION
  // ==============================

  const goHome = () => {
    setActivePage("home");
  };

  const goEvents = async () => {
    await loadEvents();
    setActivePage("events");
  };

  const goCreateEvent = () => {
    setActivePage("create-event");
  };

  const goRegister = async () => {
    await loadEvents();
    setActivePage("register");
  };

  const goCreateTeam = async () => {
    await loadEvents();
    setActivePage("create-team");
  };

  const goMyEvents = async () => {
    await loadEvents();
    setActivePage("my-events");
  };

  const goParticipants = async () => {
    await loadParticipants();
    setActivePage("participants");
  };

  const goAdmin = async () => {
    await loadEvents();
    await loadParticipants();
    setActivePage("admin");
  };

  // ==============================
  // EVENT FORM
  // ==============================

  const handleEventChange = (e) => {
    setEventForm({
      ...eventForm,
      [e.target.name]: e.target.value
    });
  };

  // ==============================
  // CREATE EVENT
  // ==============================

  const handleCreateEvent = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch("/api/events", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(eventForm)
      });

      const data = await response.json();

      if (!response.ok) {
        alert(data.message || "Failed to create event");
        return;
      }

      alert("Event created successfully!");

      setEventForm({
        title: "",
        description: "",
        date: "",
        venue: "",
        maxParticipants: ""
      });

      await loadEvents();
      setActivePage("events");
    } catch (error) {
      console.error(error);
      alert("Server error while creating event");
    }
  };

  // ==============================
  // DELETE EVENT
  // ==============================

  const handleDeleteEvent = async (id) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this event?"
    );

    if (!confirmDelete) {
      return;
    }

    try {
      const response = await fetch(`/api/events/${id}`, {
        method: "DELETE"
      });

      const data = await response.json();

      if (!response.ok) {
        alert(data.message || "Failed to delete event");
        return;
      }

      alert("Event deleted successfully!");

      await loadEvents();
    } catch (error) {
      console.error(error);
      alert("Server error while deleting event");
    }
  };

  // ==============================
  // REGISTRATION
  // ==============================

  const handleRegistrationChange = (e) => {
    setRegistrationForm({
      ...registrationForm,
      [e.target.name]: e.target.value
    });
  };

  const handleRegister = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch("/api/registrations", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(registrationForm)
      });

      const data = await response.json();

      if (!response.ok) {
        alert(data.message || "Registration failed");
        return;
      }

      alert("Registration successful!");

      setRegistrationForm({
        eventId: "",
        name: "",
        email: "",
        phone: ""
      });

      await loadParticipants();
      setActivePage("events");
    } catch (error) {
      console.error(error);
      alert("Server error while registering");
    }
  };

  // ==============================
  // TEAM
  // ==============================

  const handleTeamChange = (e) => {
    setTeamForm({
      ...teamForm,
      [e.target.name]: e.target.value
    });
  };

  const handleMemberChange = (index, field, value) => {
    const updatedMembers = [...teamForm.members];

    updatedMembers[index] = {
      ...updatedMembers[index],
      [field]: value
    };

    setTeamForm({
      ...teamForm,
      members: updatedMembers
    });
  };

  const addMember = () => {
    setTeamForm({
      ...teamForm,
      members: [
        ...teamForm.members,
        {
          name: "",
          email: ""
        }
      ]
    });
  };

  const handleCreateTeam = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch("/api/teams", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(teamForm)
      });

      const data = await response.json();

      if (!response.ok) {
        alert(data.message || "Team creation failed");
        return;
      }

      alert("Team created successfully!");

      setTeamForm({
        eventId: "",
        teamName: "",
        leaderName: "",
        members: [
          {
            name: "",
            email: ""
          }
        ]
      });

      setActivePage("home");
    } catch (error) {
      console.error(error);
      alert("Server error while creating team");
    }
  };

  // ==============================
  // EVENT STATUS
  // ==============================

  const getEventStatus = (date) => {
    const eventDate = new Date(date);
    const today = new Date();

    eventDate.setHours(0, 0, 0, 0);
    today.setHours(0, 0, 0, 0);

    return eventDate < today ? "Completed" : "Upcoming";
  };

  // ==============================
  // SEARCH + FILTER
  // ==============================

  const filteredEvents = events.filter((event) => {
    const search = searchTerm.toLowerCase().trim();

    const title = event.title?.toLowerCase() || "";
    const description = event.description?.toLowerCase() || "";
    const venue = event.venue?.toLowerCase() || "";

    const matchesSearch =
      title.includes(search) ||
      description.includes(search) ||
      venue.includes(search);

    const status = getEventStatus(event.date);

    const matchesFilter =
      statusFilter === "All" ||
      status === statusFilter;

    return matchesSearch && matchesFilter;
  });

  return (
    <div className="app">

      {/* ================= NAVBAR ================= */}

      <nav className="navbar">

        <div
          className="logo"
          onClick={goHome}
        >
          Campus<span>Event</span>
        </div>

        <div className="nav-links">

          <button onClick={goHome}>
            Home
          </button>

          <button onClick={goEvents}>
            Events
          </button>

          <button onClick={goCreateEvent}>
            Create Event
          </button>

          <button onClick={goRegister}>
            Register
          </button>

          <button onClick={goCreateTeam}>
            Create Team
          </button>

          <button onClick={goMyEvents}>
            My Events
          </button>

          <button onClick={goParticipants}>
            Participants
          </button>

          <button onClick={goAdmin}>
            Admin
          </button>

        </div>
      </nav>


      {/* ================= HOME ================= */}

      {activePage === "home" && (
        <Home
          goEvents={goEvents}
          goCreateEvent={goCreateEvent}
          goRegister={goRegister}
          goCreateTeam={goCreateTeam}
        />
      )}


      {/* ================= CREATE EVENT ================= */}

      {activePage === "create-event" && (
        <section className="page-section">

          <h1>Create New Event</h1>

          <p className="section-subtitle">
            Create and manage your college events.
          </p>

          <form
            className="form-card"
            onSubmit={handleCreateEvent}
          >

            <input
              type="text"
              name="title"
              placeholder="Event Title"
              value={eventForm.title}
              onChange={handleEventChange}
              required
            />

            <textarea
              name="description"
              placeholder="Event Description"
              value={eventForm.description}
              onChange={handleEventChange}
              required
            />

            <input
              type="date"
              name="date"
              value={eventForm.date}
              onChange={handleEventChange}
              required
            />

            <input
              type="text"
              name="venue"
              placeholder="Venue"
              value={eventForm.venue}
              onChange={handleEventChange}
              required
            />

            <input
              type="number"
              name="maxParticipants"
              placeholder="Maximum Participants"
              value={eventForm.maxParticipants}
              onChange={handleEventChange}
              required
              min="1"
            />

            <button
              type="submit"
              className="primary-btn"
            >
              Create Event
            </button>

          </form>

        </section>
      )}


      {/* ================= EVENTS ================= */}

      {activePage === "events" && (
        <section className="page-section">

          <h1>Browse Events</h1>

          <p className="section-subtitle">
            Explore all campus events.
          </p>

          {/* SEARCH */}

          <div className="search-filter">

            <input
              type="text"
              placeholder="🔍 Search event..."
              value={searchTerm}
              onChange={(e) =>
                setSearchTerm(e.target.value)
              }
            />

            <select
              value={statusFilter}
              onChange={(e) =>
                setStatusFilter(e.target.value)
              }
            >

              <option value="All">
                All Events
              </option>

              <option value="Upcoming">
                Upcoming
              </option>

              <option value="Completed">
                Completed
              </option>

            </select>

          </div>


          {/* EVENTS */}

          <div className="event-grid">

            {filteredEvents.length === 0 ? (

              <div className="empty-state">

                <h3>
                  No events found
                </h3>

                <p>
                  Try another search or filter.
                </p>

              </div>

            ) : (

              filteredEvents.map((event) => (

                <EventCard
                  key={event._id}
                  event={event}
                  onDelete={handleDeleteEvent}
                  onRegister={goRegister}
                />

              ))

            )}

          </div>

        </section>
      )}


      {/* ================= REGISTER ================= */}

      {activePage === "register" && (
        <section className="page-section">

          <h1>Event Registration</h1>

          <p className="section-subtitle">
            Register for your favourite campus event.
          </p>

          <form
            className="form-card"
            onSubmit={handleRegister}
          >

            <select
              name="eventId"
              value={registrationForm.eventId}
              onChange={handleRegistrationChange}
              required
            >

              <option value="">
                Select Event
              </option>

              {events.map((event) => (

                <option
                  key={event._id}
                  value={event._id}
                >
                  {event.title}
                </option>

              ))}

            </select>


            <input
              type="text"
              name="name"
              placeholder="Your Name"
              value={registrationForm.name}
              onChange={handleRegistrationChange}
              required
            />


            <input
              type="email"
              name="email"
              placeholder="Email Address"
              value={registrationForm.email}
              onChange={handleRegistrationChange}
              required
            />


            <input
              type="tel"
              name="phone"
              placeholder="Phone Number"
              value={registrationForm.phone}
              onChange={handleRegistrationChange}
              required
            />


            <button
              type="submit"
              className="primary-btn"
            >
              Register Now
            </button>

          </form>

        </section>
      )}


      {/* ================= CREATE TEAM ================= */}

      {activePage === "create-team" && (
        <section className="page-section">

          <h1>Create Your Team</h1>

          <p className="section-subtitle">
            Build a team for hackathons and competitions.
          </p>

          <form
            className="form-card"
            onSubmit={handleCreateTeam}
          >

            <select
              name="eventId"
              value={teamForm.eventId}
              onChange={handleTeamChange}
              required
            >

              <option value="">
                Select Event
              </option>

              {events.map((event) => (

                <option
                  key={event._id}
                  value={event._id}
                >
                  {event.title}
                </option>

              ))}

            </select>


            <input
              type="text"
              name="teamName"
              placeholder="Team Name"
              value={teamForm.teamName}
              onChange={handleTeamChange}
              required
            />


            <input
              type="text"
              name="leaderName"
              placeholder="Team Leader Name"
              value={teamForm.leaderName}
              onChange={handleTeamChange}
              required
            />


            <h3>
              Team Members
            </h3>


            {teamForm.members.map(
              (member, index) => (

                <div
                  className="member-box"
                  key={index}
                >

                  <input
                    type="text"
                    placeholder={`Member ${index + 1} Name`}
                    value={member.name}
                    onChange={(e) =>
                      handleMemberChange(
                        index,
                        "name",
                        e.target.value
                      )
                    }
                    required
                  />

                  <input
                    type="email"
                    placeholder={`Member ${index + 1} Email`}
                    value={member.email}
                    onChange={(e) =>
                      handleMemberChange(
                        index,
                        "email",
                        e.target.value
                      )
                    }
                    required
                  />

                </div>

              )
            )}


            <button
              type="button"
              className="secondary-btn"
              onClick={addMember}
            >
              + Add Member
            </button>


            <button
              type="submit"
              className="primary-btn"
            >
              Create Team
            </button>

          </form>

        </section>
      )}


      {/* ================= MY EVENTS ================= */}

      {activePage === "my-events" && (
        <section className="page-section">

          <h1>My Events</h1>

          <p className="section-subtitle">
            Manage available campus events.
          </p>

          <div className="event-grid">

            {events.length === 0 ? (

              <div className="empty-state">
                <h3>
                  No events available
                </h3>
              </div>

            ) : (

              events.map((event) => (

                <EventCard
                  key={event._id}
                  event={event}
                  onDelete={handleDeleteEvent}
                  onRegister={goRegister}
                />

              ))

            )}

          </div>

        </section>
      )}


      {/* ================= PARTICIPANTS ================= */}

      {activePage === "participants" && (
        <section className="page-section">

          <h1>Participants</h1>

          <p className="section-subtitle">
            View all registered participants.
          </p>

          <div className="participant-grid">

            {participants.length === 0 ? (

              <div className="empty-state">

                <h3>
                  No participants yet
                </h3>

                <p>
                  Registered participants will appear here.
                </p>

              </div>

            ) : (

              participants.map((participant) => (

                <div
                  className="participant-card"
                  key={participant._id}
                >

                  <h3>
                    {participant.name}
                  </h3>

                  <p>
                    📧 {participant.email}
                  </p>

                  <p>
                    📱 {participant.phone}
                  </p>

                  <p>
                    🎯{" "}
                    {participant.eventId
                      ? participant.eventId.title
                      : "Event"}
                  </p>

                </div>

              ))

            )}

          </div>

        </section>
      )}


      {/* ================= ADMIN DASHBOARD ================= */}

      {activePage === "admin" && (
        <AdminDashboard
          events={events}
          participants={participants}
          onDelete={handleDeleteEvent}
        />
      )}


      {/* ================= FOOTER ================= */}

      <footer className="footer">

        <h3>
          CampusEvent
        </h3>

        <p>
          Campus Event & Hackathon Manager
        </p>

        <p>
          © 2026 CampusEvent
        </p>

      </footer>

    </div>
  );
}


// =====================================================
// HOME
// =====================================================

function Home({
  goEvents,
  goCreateEvent,
  goRegister,
  goCreateTeam
}) {
  return (
    <>

      <section className="hero">

        <div className="hero-content">

          <p className="hero-small">
            COLLEGE EVENT MANAGEMENT
          </p>

          <h1>
            Discover.
            <br />
            Participate.
            <br />
            <span>Achieve.</span>
          </h1>

          <p>
            Manage campus events, hackathons,
            workshops and competitions in one
            simple platform.
          </p>

          <div className="hero-buttons">

            <button
              className="primary-btn"
              onClick={goEvents}
            >
              Explore Events
            </button>

            <button
              className="secondary-btn"
              onClick={goCreateEvent}
            >
              Create Event
            </button>

          </div>

        </div>

      </section>


      <section className="features-section">

        <h2>
          Everything You Need
        </h2>

        <p className="section-subtitle">
          One platform for managing your campus events.
        </p>


        <div className="features">

          <div className="feature-card">

            <div className="feature-icon">
              📅
            </div>

            <h3>
              Event Management
            </h3>

            <p>
              Create and manage college events easily.
            </p>

          </div>


          <div className="feature-card">

            <div className="feature-icon">
              👥
            </div>

            <h3>
              Easy Registration
            </h3>

            <p>
              Students can register for events quickly.
            </p>

          </div>


          <div className="feature-card">

            <div className="feature-icon">
              🚀
            </div>

            <h3>
              Team Creation
            </h3>

            <p>
              Build teams for hackathons and competitions.
            </p>

          </div>


          <div className="feature-card">

            <div className="feature-icon">
              📊
            </div>

            <h3>
              Admin Dashboard
            </h3>

            <p>
              Monitor events and participants.
            </p>

          </div>

        </div>

      </section>


      <section className="cta-section">

        <h2>
          Ready to Join an Event?
        </h2>

        <p>
          Explore events and start participating today.
        </p>

        <button
          className="primary-btn"
          onClick={goRegister}
        >
          Register Now
        </button>

      </section>

    </>
  );
}


// =====================================================
// EVENT CARD
// =====================================================

function EventCard({
  event,
  onDelete,
  onRegister
}) {
  const eventStatus = getStatus(event.date);

  return (
    <div className="event-card">

      <div className="event-card-top">

        <span
          className={
            eventStatus === "Upcoming"
              ? "status upcoming"
              : "status completed"
          }
        >
          {eventStatus}
        </span>

      </div>


      <h3>
        {event.title}
      </h3>


      <p>
        {event.description}
      </p>


      <div className="event-info">

        <p>
          📅{" "}
          {new Date(
            event.date
          ).toLocaleDateString()}
        </p>

        <p>
          📍 {event.venue}
        </p>

        <p>
          👥 Maximum Participants:{" "}
          {event.maxParticipants}
        </p>

      </div>


      <div className="event-actions">

        <button
          className="primary-btn"
          onClick={onRegister}
        >
          Register
        </button>


        <button
          className="delete-btn"
          onClick={() =>
            onDelete(event._id)
          }
        >
          🗑 Delete Event
        </button>

      </div>

    </div>
  );
}


// =====================================================
// EVENT STATUS FUNCTION
// =====================================================

function getStatus(date) {
  const eventDate = new Date(date);
  const today = new Date();

  eventDate.setHours(0, 0, 0, 0);
  today.setHours(0, 0, 0, 0);

  return eventDate < today
    ? "Completed"
    : "Upcoming";
}


// =====================================================
// ADMIN DASHBOARD
// =====================================================

function AdminDashboard({
  events,
  participants,
  onDelete
}) {
  const upcomingEvents = events.filter(
    (event) =>
      getStatus(event.date) === "Upcoming"
  ).length;

  const completedEvents = events.filter(
    (event) =>
      getStatus(event.date) === "Completed"
  ).length;


  return (
    <section className="page-section">

      <h1>
        Admin Dashboard
      </h1>

      <p className="section-subtitle">
        Monitor and manage campus events.
      </p>


      {/* STATISTICS */}

      <div className="features">

        <div className="feature-card">

          <div className="feature-icon">
            📅
          </div>

          <h3>
            Total Events
          </h3>

          <h2>
            {events.length}
          </h2>

        </div>


        <div className="feature-card">

          <div className="feature-icon">
            🚀
          </div>

          <h3>
            Upcoming Events
          </h3>

          <h2>
            {upcomingEvents}
          </h2>

        </div>


        <div className="feature-card">

          <div className="feature-icon">
            👥
          </div>

          <h3>
            Total Participants
          </h3>

          <h2>
            {participants.length}
          </h2>

        </div>


        <div className="feature-card">

          <div className="feature-icon">
            ✅
          </div>

          <h3>
            Completed Events
          </h3>

          <h2>
            {completedEvents}
          </h2>

        </div>

      </div>


      {/* EVENT SUMMARY */}

      <div className="dashboard-card">

        <h2>
          Event Summary
        </h2>

        {events.length === 0 ? (

          <p>
            No events available.
          </p>

        ) : (

          events.map((event) => {

            const registeredCount =
              participants.filter(
                (participant) =>
                  participant.eventId &&
                  participant.eventId._id ===
                    event._id
              ).length;

            return (
              <div
                className="dashboard-row"
                key={event._id}
              >

                <div>

                  <h3>
                    {event.title}
                  </h3>

                  <p>
                    📍 {event.venue}
                  </p>

                </div>


                <div>

                  <strong>
                    {registeredCount}
                  </strong>

                  <p>
                    Registered
                  </p>

                </div>

              </div>
            );
          })

        )}

      </div>


      {/* MANAGE EVENTS */}

      <div className="dashboard-card">

        <h2>
          Manage Events
        </h2>

        <div className="event-grid">

          {events.map((event) => (

            <EventCard
              key={event._id}
              event={event}
              onDelete={onDelete}
              onRegister={() => {}}
            />

          ))}

        </div>

      </div>

    </section>
  );
}


export default App;